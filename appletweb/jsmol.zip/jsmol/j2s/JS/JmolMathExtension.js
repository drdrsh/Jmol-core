Clazz.declarePackage ("JS");
Clazz.declareInterface (JS, "JmolMathExtension");
